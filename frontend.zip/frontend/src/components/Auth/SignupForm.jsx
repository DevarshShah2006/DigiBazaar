import { useState } from 'react'
import { signup } from '../../api/auth'

function SignupForm() {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)

  const handleSubmit = async event => {
    event.preventDefault()
    setError(null)
    try {
      const data = await signup({ username, email, password })
      console.log('Signup successful', data)
    } catch (err) {
      setError('Signup failed. Please check your details.')
    }
  }

  return (
    <form className='auth-form' onSubmit={handleSubmit}>
      <h2>Signup</h2>
      <label>
        Username
        <input value={username} onChange={e => setUsername(e.target.value)} required />
      </label>
      <label>
        Email
        <input type='email' value={email} onChange={e => setEmail(e.target.value)} required />
      </label>
      <label>
        Password
        <input type='password' value={password} onChange={e => setPassword(e.target.value)} required />
      </label>
      {error && <p className='error'>{error}</p>}
      <button type='submit'>Signup</button>
    </form>
  )
}

export default SignupForm
