import { useState } from 'react'
import { login } from '../../api/auth'

function LoginForm() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)

  const handleSubmit = async event => {
    event.preventDefault()
    setError(null)
    try {
      const data = await login({ username, password })
      console.log('Login successful', data)
    } catch (err) {
      setError('Login failed. Check your credentials.')
    }
  }

  return (
    <form className='auth-form' onSubmit={handleSubmit}>
      <h2>Login</h2>
      <label>
        Username
        <input value={username} onChange={e => setUsername(e.target.value)} required />
      </label>
      <label>
        Password
        <input type='password' value={password} onChange={e => setPassword(e.target.value)} required />
      </label>
      {error && <p className='error'>{error}</p>}
      <button type='submit'>Login</button>
    </form>
  )
}

export default LoginForm
