import LoginForm from '../../components/Auth/LoginForm'
import './Login.css'

function Login() {
  return (
    <section className='auth-page'>
      <LoginForm />
    </section>
  )
}

export default Login
