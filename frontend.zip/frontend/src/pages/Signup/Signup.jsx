import SignupForm from '../../components/Auth/SignupForm'
import './Signup.css'

function Signup() {
  return (
    <section className='auth-page'>
      <SignupForm />
    </section>
  )
}

export default Signup
